import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

// Add this import statement for DatabaseHelper
import com.bobbyeigenfeld.projecttwo.DatabaseHelper;

public class DataActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private EditText itemInput, detailInput;
    private Button addButton;
    private DatabaseHelper databaseHelper;  // This should now be recognized

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Initialize views
        recyclerView = findViewById(R.id.recyclerView);
        itemInput = findViewById(R.id.itemInput);
        detailInput = findViewById(R.id.detailInput);
        addButton = findViewById(R.id.addButton);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(databaseHelper.getAllItems());
        recyclerView.setAdapter(adapter);

        // Set up Add button listener
        addButton.setOnClickListener(v -> {
            String name = itemInput.getText().toString();
            String detail = detailInput.getText().toString();

            if (!name.isEmpty() && !detail.isEmpty()) {
                // Insert data into the database
                boolean result = databaseHelper.insertItem(name, detail);
                if (result) {
                    Toast.makeText(DataActivity.this, "Item added", Toast.LENGTH_SHORT).show();
                    itemInput.setText("");
                    detailInput.setText("");

                    // Update RecyclerView with new data
                    updateRecyclerView();
                } else {
                    Toast.makeText(DataActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(DataActivity.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to update RecyclerView with new data
    private void updateRecyclerView() {
        List<ItemModel> itemList = databaseHelper.getAllItems();  // Fetch updated data from the database
        adapter.updateData(itemList);  // Update the adapter with new data
    }
}
