package com.bobbyeigenfeld.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button loginButton, createAccountButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view layout
        setContentView(R.layout.activity_main);

        // Apply window insets for immersive UI (Edge-to-Edge)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize buttons
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Set click listeners for the buttons
        loginButton.setOnClickListener(v -> {
            // Navigate to DataActivity
            Intent intent = new Intent(MainActivity.this, DataActivity.class);
            startActivity(intent);
        });

        createAccountButton.setOnClickListener(v -> {
            // Navigate to SmsActivity
            Intent intent = new Intent(MainActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }
}
