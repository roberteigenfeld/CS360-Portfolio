package com.bobbyeigenfeld.projecttwo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private GridView gridView;
    private Button viewItemsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Initialize the GridView and Button
        gridView = findViewById(R.id.gridView);
        viewItemsButton = findViewById(R.id.viewItemsButton);

        // Set up the click listener for the View Items button
        viewItemsButton.setOnClickListener(v -> {
            // Fetch data from the database as a List<ItemModel>
            List<ItemModel> itemList = dbHelper.getAllItems();

            if (itemList != null && !itemList.isEmpty()) {
                // Set up the custom adapter to bind data to GridView
                ItemAdapter itemAdapter = new ItemAdapter(HomeActivity.this, itemList);
                gridView.setAdapter(itemAdapter);

                // Make the GridView visible
                gridView.setVisibility(View.VISIBLE);
            } else {
                Toast.makeText(HomeActivity.this, "No items found", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
