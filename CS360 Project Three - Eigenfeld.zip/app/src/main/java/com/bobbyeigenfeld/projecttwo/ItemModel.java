package com.bobbyeigenfeld.projecttwo;

public class ItemModel {
    private int id;
    private String itemName;
    private String itemDetail;

    // Constructors
    public ItemModel(int id, String itemName, String itemDetail) {
        this.id = id;
        this.itemName = itemName;
        this.itemDetail = itemDetail;
    }

    public ItemModel(String itemName, String itemDetail) {
        this.itemName = itemName;
        this.itemDetail = itemDetail;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemDetail() {
        return itemDetail;
    }

    // Setters (optional)
    public void setId(int id) {
        this.id = id;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemDetail(String itemDetail) {
        this.itemDetail = itemDetail;
    }

    // Override for debugging and logging
    @Override
    public String toString() {
        return "ItemModel{id=" + id + ", itemName='" + itemName + "', itemDetail='" + itemDetail + "'}";
    }
}
